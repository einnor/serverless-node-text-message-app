# serverless-node-text-message-app

A Node text message app created with the Serverless Framework.