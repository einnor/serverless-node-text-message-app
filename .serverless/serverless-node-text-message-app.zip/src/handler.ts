export { validateAndSend } from './functions/validateAndSend';
