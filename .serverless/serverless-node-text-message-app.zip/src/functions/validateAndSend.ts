import { Context, Callback, Handler, APIGatewayProxyResult } from 'aws-lambda';
import { sendMessage } from '../lib/Twilio';
import { validateRecaptcha } from '../lib/Recaptcha';
import { IEvent } from '../types';

export const validateAndSend: Handler = async (event: IEvent, context: Context, callback: Callback<APIGatewayProxyResult>) => {
  // Required in responses for CORS support to work
  const headers = {'Access-Control-Allow-Origin': '*'};

  // event.body = {
  //   "captcha": "03AOLTBLQzSV4zuHq9p33YPQc_x1x0khCu93LVvsYhnaEchuIHwRHCWUiAMHgquTZfP7voE9RX0Y6cz1Jk1EQnTMoYj1BaWjYMg-AyysuBjkptXxYHt34RmAgHVOMDmBX1BHBOmdYFUd-9nItgIE-0I9H74wfHfrk4uekoCOdIXWZbb715_AkG4TV6mXcR6wqDuR0cl4iLPSxioVtTwUxwK3EhwqgHqR1VxKGPR2I_jm3PLbPmdOTFVfLvVK0hzHpNseHCP_7NAOCgoeVl9TtwMf_IC4hXISm6JfMGHluG-VxKi1bTynaM5MTIX4COw4Li_A-w9K92r8xkCSEJBcTOhhiLEGDrRw7UXZSEf0ut5qpyB9WDuBYw_G_dEHM94__3k3cIrWTMNaYbSZoGojuHtVOloCvUwaj0YQ_lr4xv-PuJkbbYIwMNzpL3GEYglIH6-LYiZJXgaEH3t6q78yfLb27ZySahMrB6EQ",
  //   "message": "Woof Garden from Test Environment",
  //   "to": "254724052900"
  // };

  // Validations
  if (!event.body) {
    throw new Error('Request body is invalid');
  }

  if (!event.body.captcha) {
    throw new Error('Captcha is invalid');
  }

  try {
    const recaptchaResponse = await validateRecaptcha(event.body.captcha, callback);

    if (recaptchaResponse) {
      sendMessage(event.body.to, event.body.message, callback);
    }
  } catch (error) {
    const errResponse = {
      headers: headers,
      statusCode: 500,
      body: JSON.stringify({
        status: 'fail',
        message: 'Something went wrong.',
        error: error
      }),
    };

    return callback(null, errResponse);
  }
};
